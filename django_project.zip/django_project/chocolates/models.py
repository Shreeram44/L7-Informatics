from django.db import models



class SeasonalFlavor(models.Model):
    name = models.CharField(max_length=100)
    available = models.BooleanField(default=True)

    def __str__(self):
        return self.name


class IngredientInventory(models.Model):
    ingredient_name = models.CharField(max_length=100)
    stock_level = models.IntegerField()

    def __str__(self):
        return self.ingredient_name


class CustomerFeedback(models.Model):
    name = models.CharField(max_length=100)
    suggestion = models.TextField()
    allergy_concerns = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name