from django import forms
from .models import CustomerFeedback

class CustomerFeedbackForm(forms.ModelForm):
    class Meta:
        model = CustomerFeedback
        fields = ['name', 'suggestion', 'allergy_concerns']
