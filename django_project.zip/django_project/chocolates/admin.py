from django.contrib import admin
from .models import SeasonalFlavor, IngredientInventory, CustomerFeedback

admin.site.register(SeasonalFlavor)
admin.site.register(IngredientInventory)
admin.site.register(CustomerFeedback)
