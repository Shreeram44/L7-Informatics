from django.shortcuts import render, redirect
from .models import SeasonalFlavor, IngredientInventory, CustomerFeedback
from .forms import CustomerFeedbackForm

def index(request):
    flavors = SeasonalFlavor.objects.all()
    ingredients = IngredientInventory.objects.all()
    return render(request, 'chocolates/index.html', {'flavors': flavors, 'ingredients': ingredients})

def feedback(request):
    if request.method == 'POST':
        form = CustomerFeedbackForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('index')
    else:
        form = CustomerFeedbackForm()
    return render(request, 'chocolates/feedback.html', {'form': form})
